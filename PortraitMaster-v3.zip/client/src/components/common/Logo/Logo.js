import './Logo.scss';

const Logo = () => (
  <img src="/img/logo.png" className="logo" alt="" />
);

export default Logo;
