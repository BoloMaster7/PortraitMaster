import { Container } from 'reactstrap';

const TermsOfUse = () => (
  <Container>
    <h1>Terms of use</h1>
    <p>To do...</p>
  </Container>
);

export default TermsOfUse;
