import { Container } from 'reactstrap';

const NotFoundPage = () => (
  <Container>
    <h1 className="text-center">404 Not Found</h1>
  </Container>
);

export default NotFoundPage;
